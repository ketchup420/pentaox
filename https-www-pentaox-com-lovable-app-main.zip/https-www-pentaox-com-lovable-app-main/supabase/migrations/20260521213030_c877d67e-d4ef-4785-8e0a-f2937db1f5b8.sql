-- Explicitly deny SELECT on leads to anon and authenticated roles.
-- Service role bypasses RLS and can still read leads from server-side admin code.
CREATE POLICY "No public reads of leads"
ON public.leads
FOR SELECT
TO anon, authenticated
USING (false);