## Goal

Tighten SEO on the homepage and make the hero, agent cards, demo tiles, and section spacing feel balanced on every screen — especially the narrow mobile viewport the user is currently previewing (458px).

## 1. SEO — homepage hero & social sharing

In `src/routes/index.tsx` `head()`:
- Sharper title: `"PentaOx — AI Agents, Node.js Apps & Real Solutions"` (under 60 chars, leads with what we do).
- Description rewritten with keywords + value prop, ~150 chars: `"PentaOx builds AI agents (OpenClaw & Hermes), Node.js apps, and integrations that fix real business pain points. Diagnosis first — solutions, not just AI."`.
- Add `og:type: website`, `og:site_name`, full set of `og:` and `twitter:` tags (title, description, image, card=`summary_large_image`).
- Use absolute `og:url` and `og:image` against `https://pentaox-solutions-hub.lovable.app`. Reuse the OG image already configured in `__root.tsx`.
- Add page-scoped JSON-LD `WebSite` block with `name`, `url`, and `potentialAction` (sitelinks search box stub) — complements the root `Organization` schema.
- Add `<link rel="canonical">` only on the leaf (per the canonical dedupe rule).

No changes to `__root.tsx` head — defaults stay.

## 2. Responsive typography with `clamp()`

Apply fluid sizes via inline `style={{ fontSize: "clamp(min, vw, max)" }}` (consistent with the hero pattern already used):

- **Agents preview** (`Meet the agents`):
  - Section heading: `clamp(1.5rem, 4vw, 2.25rem)`
  - Agent name: `clamp(1.125rem, 2.6vw, 1.5rem)`
  - Tag + description: `clamp(0.75rem, 1.4vw, 0.875rem)`
- **Demo tiles**:
  - Title: `clamp(0.95rem, 1.8vw, 1.125rem)`
  - Description: `clamp(0.75rem, 1.3vw, 0.875rem)`
  - Status pill stays at `text-[10px]`.
- **Buttons / CTAs in hero**:
  - Primary + secondary CTA: `clamp(0.8rem, 1.4vw, 0.95rem)`, padding tightened on small screens (`px-5 py-3` mobile → `sm:px-7 sm:py-3.5`).
  - Jump-to anchors keep `text-xs` but get `min-h-9` for tap target.
- **Why PentaOx** + final CTA headline: `clamp(1.5rem, 4.5vw, 3rem)` so it scales like the hero h1.

## 3. Section spacing & padding

Currently every section uses `py-16` / `py-20` regardless of viewport. Rebalance:

- Hero section: drop `mb-16` → `mb-8 sm:mb-12`. Reduce hero height on mobile: `h-[88vh] min-h-[600px]` → `h-[78vh] min-h-[520px] sm:h-[88vh] sm:min-h-[600px]`.
- Agents preview: `py-16` → `py-10 sm:py-14 lg:py-20`.
- Demo Work: same `py-10 sm:py-14 lg:py-20`; tile padding `p-6` → `p-5 sm:p-6`; grid gap `gap-6` → `gap-4 sm:gap-6`.
- Why PentaOx: `py-16` → `py-10 sm:py-14 lg:py-20`.
- Final CTA: `py-20` → `py-12 sm:py-16 lg:py-20`; inner padding `p-10 sm:p-16` → `p-6 sm:p-10 lg:p-16`.
- `SiteShell` already provides horizontal padding — no changes there.

## 4. Hero video overlay & safe-area on mobile

Improve legibility and avoid the headline colliding with the system status bar / browser chrome on mobile.

- Wrap the hero copy container in `pt-[max(env(safe-area-inset-top),1rem)] pb-[max(env(safe-area-inset-bottom),1rem)]` so iOS notches and the address bar don't cover the badge or the ticker.
- Strengthen overlay on mobile where the video competes with text:
  - Replace the single bottom gradient with a stacked overlay:
    - Bottom-up: `from-background via-background/70 to-background/10` (was `from-background/40 via-background/20 to-background`).
    - Add a subtle radial vignette behind the copy block: a `div` with `bg-[radial-gradient(ellipse_at_left,oklch(0.18_0.04_270/0.7),transparent_60%)]` so text-side stays dark on small screens, tapering off on `sm:` and up.
  - Drop the side gradient on mobile (`hidden sm:block`) to avoid double-darkening narrow viewports.
- Move the Ticker out of `absolute bottom-6` on mobile (it currently overlaps the CTAs at <500px). Make it `static mt-6 sm:absolute sm:bottom-6 sm:left-1/2 sm:-translate-x-1/2` and constrain width with `max-w-[90vw]`.
- Ticker internal padding `p-6` → `p-4 sm:p-6`; font sizes go through `clamp()` similarly.
- Ensure `<video>` keeps `object-cover` and add `poster="/ox-logo.jpg"` for a visible fallback on slow networks.

## 5. QA

- Verify build passes (auto by harness).
- Visually check at 458×672 (current viewport), 768, and 1280 widths via the preview.
- Confirm SEO tags render in `<head>` for `/` (no canonical duplication with root).

## Out of scope

- Visual restyling of `/agents`, `/contact`, `/services` pages.
- Changes to `__root.tsx` defaults.
- New imagery or video re-encoding.
